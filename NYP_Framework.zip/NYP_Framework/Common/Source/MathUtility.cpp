#include "MathUtility.h"

int factorial(int n)
{
	return 1;
}

int nCr(int n, int r)
{
	return 0;
}

int nPr(int n, int r)
{
	return 0;
}

int nTermAP(int a, int d, int n)
{
	return 0;
}

int summationAP(int a, int d, int n)
{
	return 0;
}

int nTermGP(int a, int r, int n)
{
	return 0;
}

int summationGP(int a, int r, int n)
{
	return 0;
}