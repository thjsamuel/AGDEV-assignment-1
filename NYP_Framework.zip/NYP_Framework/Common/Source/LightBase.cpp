#include "LightBase.h"

LightBase::LightBase()
{
}

LightBase::~LightBase()
{
}

void LightBase::Update(double _dt)
{
}

void LightBase::UpdateUniforms()
{
}